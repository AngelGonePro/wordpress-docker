# WordPress on SQLite (Linode / no MySQL)

Self-contained WordPress stack: no external database, static-page
caching, auto-updating core/plugins, and a verify-then-promote update
script with automatic rollback.

## First run

1. Edit `.env` -- fill in the `CHANGE-ME` values (salts, admin password,
   site URL/email). Everything else already has real, working defaults.
2. `docker compose up -d --build`
3. Watch the one-shot installer finish: `docker compose logs -f wp-init`
   (it runs the WordPress install wizard headlessly and activates
   Cache Enabler + Rank Math, then exits -- that's expected).
4. Open the site, log into `/wp-admin`, and click through Rank Math's
   setup wizard once (its free-tier account connection needs a browser
   for the OAuth step -- everything else about this stack is automated).

## Updating

Bump any `*_VERSION` (or `WORDPRESS_BASE_IMAGE`) in `.env`, then:

```
./update.sh
```

This builds a candidate image and health-checks it in total isolation
(read-only, no network) before it ever touches the live containers. If
the candidate fails, the live site is never touched. If the live site
fails its own health check after being recreated, it's automatically
rolled back to the previous working image. Either way, nothing is
printed to `update-failures.log` unless something actually broke --
check that file, not your terminal scrollback, after a failed run.

For the base OS/PHP layer specifically (not something WordPress can
patch itself), `systemd/wordpress-update.timer` runs `update.sh`
weekly. Edit the `WorkingDirectory`/`ExecStart` paths in
`systemd/wordpress-update.service` to match wherever you put this
directory on the host, then:

```
sudo cp systemd/wordpress-update.* /etc/systemd/system/
sudo systemctl enable --now wordpress-update.timer
```

WordPress core/plugin updates happen on their own via `wp-cron`
(auto-update is forced on in `docker-compose.yml`) -- `update.sh` only
covers what WordPress itself can't patch: the PHP/Apache/Debian base
image.

## Layout

- `docker-compose.yml` -- `wordpress` (app), `wp-init` (one-shot
  installer), `wp-cron` (real cron for wp-cron.php since a low-traffic
  static site can't rely on visitor-triggered pseudo-cron)
- `Dockerfile` -- pinned base image + WP-CLI + SQLite/Cache
  Enabler/Rank Math, all pinned via build args from `.env`
- `data/html/` -- the entire WordPress install, including the SQLite
  database file at `data/html/wp-content/database/.ht.sqlite` -- this
  one directory is your whole backup surface
- `update.sh` -- see "Updating" above
- `systemd/` -- weekly timer for `update.sh`

## Performance / security notes

- Cache Enabler serves static HTML for anonymous visitors (everyone,
  since there's no login/signup flow) -- PHP and SQLite are barely
  touched after the first hit per page.
- If Cloudflare Tunnel fronts this (via Nginx Proxy Manager, unchanged
  from your existing setup), add a Cache Rule for HTML at the edge,
  excluding `/wp-admin/*` and the `wordpress_logged_in_*` cookie.
- Consider putting `/wp-admin/*` and `/wp-login.php` behind Cloudflare
  Access (Zero Trust) restricted to your own email -- removes the
  brute-force surface entirely.

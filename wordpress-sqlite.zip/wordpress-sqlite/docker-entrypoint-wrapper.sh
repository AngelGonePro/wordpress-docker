#!/bin/bash
set -eo pipefail

# The whole html tree (not just wp-content) is bind-mounted now, on
# purpose: WordPress's own auto-updater rewrites core files under
# wp-admin/wp-includes, and those changes need to survive container
# recreation. If it lived only in the image layer, an auto-update would
# vanish the next time this container restarts.
if [ ! -e /var/www/html/wp-load.php ]; then
    echo "[wp-init] Fresh volume detected, seeding WordPress files..."
    tar cf - --one-file-system -C /usr/src/wordpress . | tar xf - -C /var/www/html
    chown -R www-data:www-data /var/www/html
fi

PLUGIN_DIR="/var/www/html/wp-content/plugins/sqlite-database-integration"
DB_COPY="$PLUGIN_DIR/db.copy"
DB_DROPIN="/var/www/html/wp-content/db.php"

# db.copy contains one placeholder, {SQLITE_IMPLEMENTATION_FOLDER_PATH}.
# Its own fallback logic already resolves to wp-content/plugins/sqlite-
# database-integration when that placeholder path doesn't literally exist
# on disk, which is exactly where we put it -- so a plain copy is enough.
if [ -f "$DB_COPY" ] && [ ! -f "$DB_DROPIN" ]; then
    echo "[wp-init] Installing db.php drop-in..."
    mkdir -p /var/www/html/wp-content/database
    cp "$DB_COPY" "$DB_DROPIN"
    chown -R www-data:www-data /var/www/html/wp-content/database "$DB_DROPIN"
    echo "[wp-init] Done. Database will live at wp-content/database/.ht.sqlite"
fi

# Hand off to the real WordPress entrypoint. wp-load.php now exists so it
# will skip the copy step and just generate wp-config.php (if missing)
# from WORDPRESS_* env vars, fix perms, then exec "$@" (apache2-foreground).
exec /usr/local/bin/docker-entrypoint.sh "$@"

<?php
/**
 * Must-use plugin: loads during WordPress's normal plugin bootstrap, so
 * (unlike code injected into wp-config.php via WORDPRESS_CONFIG_EXTRA)
 * add_filter() actually exists by the time this file runs. define()
 * calls stay in wp-config.php since those work fine there; only the
 * filter calls needed to move here.
 */
add_filter( 'auto_update_plugin', '__return_true' );
add_filter( 'auto_update_theme', '__return_true' );
add_filter( 'xmlrpc_enabled', '__return_false' );

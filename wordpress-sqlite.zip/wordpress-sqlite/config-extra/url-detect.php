<?php
/**
 * Included from wp-config.php (before WordPress's plugin API loads --
 * this is plain PHP only, no add_filter/add_action calls here; those
 * live in mu-plugins/hardening.php instead).
 *
 * This used to be inlined directly in docker-compose.yml's
 * WORDPRESS_CONFIG_EXTRA, but Compose does its own $VAR substitution on
 * values in that file and was silently stripping every $_SERVER
 * reference before it ever reached PHP. Living in its own file sidesteps
 * that class of bug entirely -- nothing here is Compose-interpolated.
 */

// Trust a TLS-terminating proxy's header, if one is present.
if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strpos($_SERVER['HTTP_X_FORWARDED_PROTO'], 'https') !== false) {
    $_SERVER['HTTPS'] = 'on';
}

// Detect the site URL from the actual request instead of a fixed value
// -- this is what makes one image work unmodified whether it's reached
// via a LAN IP, a real domain, http, or https. Skipped for the internal
// wp-cron ping (see the wp-cron service in docker-compose.yml) so
// cron-triggered work like Rank Math's sitemap keeps using the real
// configured URL, not the internal Docker service name "wordpress".
$is_cron_ping = (strpos($_SERVER['REQUEST_URI'] ?? '', 'wp-cron.php') !== false);
if (!empty($_SERVER['HTTP_HOST']) && !$is_cron_ping) {
    $detected_scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    define('WP_HOME', $detected_scheme . '://' . $_SERVER['HTTP_HOST']);
    define('WP_SITEURL', $detected_scheme . '://' . $_SERVER['HTTP_HOST']);
}

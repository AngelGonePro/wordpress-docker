#!/bin/bash
# Usage: ./update.sh
#
# To update: bump whichever version(s) you want in .env
# (WORDPRESS_BASE_IMAGE / WPCLI_VERSION / SQLITE_PLUGIN_VERSION /
# CACHE_ENABLER_VERSION / RANKMATH_VERSION), then run this. It does NOT
# touch the live containers until a candidate image has proven it
# actually boots and serves a page:
#
#   1. Tags the current working image as a fallback.
#   2. Builds a candidate image from the versions now in .env.
#   3. Boots the candidate in an isolated, throwaway container (read-only
#      mount of the real data, no network) and checks it responds to an
#      HTTP request.
#   4. Only if that passes: promotes the candidate, recreates the live
#      containers, and re-checks the live site.
#   5. If anything at any stage fails, the live stack is left on (or
#      rolled back to) the previous working image -- never left
#      half-updated -- and only the failure details are written to
#      update-failures.log (nothing is logged on a clean run).
set -uo pipefail
cd "$(dirname "$0")"

LOG_FILE="./update-failures.log"
TMP_LOG=$(mktemp)
IMAGE=wordpress-sqlite

cleanup() { rm -f "$TMP_LOG"; docker rm -f wp-update-test >/dev/null 2>&1 || true; }
trap cleanup EXIT

fail() {
    {
        echo "===== UPDATE FAILURE: $(date -u +%Y-%m-%dT%H:%M:%SZ) ====="
        echo "$1"
        echo
        cat "$TMP_LOG"
        echo "================================================================"
        echo
    } >> "$LOG_FILE"
    echo "[FAIL] $1 -- details written to $LOG_FILE" >&2
    exit 1
}

# shellcheck disable=SC1091
source .env

echo "==> Recording current working image as fallback ($IMAGE:previous)..."
docker tag "$IMAGE:local" "$IMAGE:previous" 2>>"$TMP_LOG" || true

echo "==> Building candidate from versions pinned in .env..."
if ! docker build \
        --pull \
        --build-arg "WORDPRESS_BASE_IMAGE=${WORDPRESS_BASE_IMAGE}" \
        --build-arg "WPCLI_VERSION=${WPCLI_VERSION}" \
        --build-arg "SQLITE_PLUGIN_VERSION=${SQLITE_PLUGIN_VERSION}" \
        --build-arg "CACHE_ENABLER_VERSION=${CACHE_ENABLER_VERSION}" \
        --build-arg "RANKMATH_VERSION=${RANKMATH_VERSION}" \
        -t "$IMAGE:candidate" . >"$TMP_LOG" 2>&1; then
    fail "docker build failed for the candidate image"
fi

echo "==> Booting candidate in isolation to verify it actually works..."
docker rm -f wp-update-test >/dev/null 2>&1 || true
if ! docker run -d --name wp-update-test \
        --network none \
        -v "$(pwd)/data/html:/var/www/html:ro" \
        "$IMAGE:candidate" apache2-foreground >"$TMP_LOG" 2>&1; then
    fail "candidate container failed to start"
fi

sleep 5

if ! docker exec wp-update-test curl -fsS -o /dev/null http://localhost/ 2>>"$TMP_LOG"; then
    docker logs wp-update-test >>"$TMP_LOG" 2>&1
    fail "candidate did not respond to an HTTP request -- image NOT promoted, live stack untouched"
fi
docker rm -f wp-update-test >/dev/null 2>&1

echo "==> Candidate is healthy. Promoting and recreating live containers..."
docker tag "$IMAGE:candidate" "$IMAGE:local"
if ! docker compose up -d --force-recreate wordpress wp-cron >"$TMP_LOG" 2>&1; then
    echo "==> Recreate failed, rolling back to previous working image..."
    docker tag "$IMAGE:previous" "$IMAGE:local"
    docker compose up -d --force-recreate wordpress wp-cron >>"$TMP_LOG" 2>&1 || true
    fail "container recreate with new image failed, rolled back to previous image"
fi

sleep 5
if ! docker exec wordpress curl -fsS -o /dev/null http://localhost/ 2>>"$TMP_LOG"; then
    echo "==> Live site unhealthy after recreate, rolling back..."
    docker tag "$IMAGE:previous" "$IMAGE:local"
    docker compose up -d --force-recreate wordpress wp-cron >>"$TMP_LOG" 2>&1 || true
    fail "live site failed its health check after update, rolled back to previous image"
fi

docker image prune -f >/dev/null 2>&1 || true
echo "==> Update complete. $IMAGE:previous kept as a manual rollback point"
echo "    (docker tag $IMAGE:previous $IMAGE:local && docker compose up -d --force-recreate wordpress wp-cron)."

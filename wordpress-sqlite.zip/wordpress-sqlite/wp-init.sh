#!/bin/bash
# Runs in a short-lived sidecar container (see docker-compose.yml) that
# shares the same html bind mount as the main "wordpress" service. It
# does the one-time install-wizard + plugin-activation steps that would
# otherwise require opening a browser, then exits.
set -eo pipefail
cd /var/www/html

echo "[wp-init] Waiting for wp-config.php..."
for i in $(seq 1 60); do
    [ -f wp-config.php ] && break
    sleep 2
done
if [ ! -f wp-config.php ]; then
    echo "[wp-init] wp-config.php never appeared after 2 minutes, aborting." >&2
    exit 1
fi

if ! wp core is-installed --allow-root 2>/dev/null; then
    echo "[wp-init] Running headless install..."
    wp core install --allow-root \
        --url="${WORDPRESS_SITE_URL:?set WORDPRESS_SITE_URL in .env}" \
        --title="${WORDPRESS_SITE_TITLE:-My Site}" \
        --admin_user="${WORDPRESS_ADMIN_USER:?set WORDPRESS_ADMIN_USER in .env}" \
        --admin_password="${WORDPRESS_ADMIN_PASSWORD:?set WORDPRESS_ADMIN_PASSWORD in .env}" \
        --admin_email="${WORDPRESS_ADMIN_EMAIL:?set WORDPRESS_ADMIN_EMAIL in .env}" \
        --skip-email
else
    echo "[wp-init] Already installed, skipping core install."
fi

echo "[wp-init] Activating cache-enabler and rank-math..."
wp plugin activate cache-enabler --allow-root || true
wp plugin activate seo-by-rank-math --allow-root || true

echo "[wp-init] Locking down public registration..."
wp option update users_can_register 0 --allow-root

echo "[wp-init] Setting pretty permalinks (Rank Math's sitemap needs this)..."
wp rewrite structure '/%postname%/' --allow-root
wp rewrite flush --hard --allow-root

echo "[wp-init] Complete."
